#The Grand Quest, a role playing game
import random
import pygame
import sys
import string
import os

PauseMenu = pygame.image.load('Pause.png')

class Back(object): 
     def __init__(self): 
         self.rect = pygame.Rect(0,0,500,500)

class Button(object): 
          def __init__(self,x,y): 
               self.rect = pygame.Rect(x,y,200,25)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
               
class Mouse(object):
     def __init__(self):
         self.rect=pygame.Rect(0,0,1,1)
         
class Centertext:
          def __init__(self, text, (x,y)):
             self.x = x
             self.y = y
             font = pygame.font.SysFont("Showcard Gothic", 20)
             self.txt = font.render(text, True, (0,0,0))
             self.size = font.size(text)
          def draw(self, screen):
             drawX = self.x - (self.size[0] / 2.)
             drawY = self.y - (self.size[1] / 2.)
             coords = (drawX, drawY)
             screen.blit(self.txt, coords)

pygame.init()
pygame.font.init()

pygame.display.set_caption("The Grand Quest")
width, height = 500, 500
screen = pygame.display.set_mode((width, height)) 
clock = pygame.time.Clock()
Running = True
back=Back()
mouse=Mouse()

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def mainmenu():
     Menu = pygame.image.load('Menu.png')
     loadbutt=Button(150,246.875)
     newbutt=Button(150,296.875)
     quitbutt=Button(150,346.875)
     mouse.rect.x,mouse.rect.y=0,0
     menuscreen=True
     while menuscreen==True:
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
                    if loadbutt.rect.colliderect(mouse.rect):
                         loadgame()
                         mouse.rect.x,mouse.rect.y=0,0
                    if newbutt.rect.colliderect(mouse.rect):
                         newgame()
                         mouse.rect.x,mouse.rect.y=0,0
                    if quitbutt.rect.colliderect(mouse.rect):
                         pygame.quit()
                         quit()
          mouse.rect.x,mouse.rect.y=0,0
          screen.fill((0,0,0))
          screen.blit(Menu,back.rect)
          pygame.draw.rect(screen,(100,100,100),loadbutt.rect)
          pygame.draw.rect(screen,(100,100,100),newbutt.rect)
          pygame.draw.rect(screen,(100,100,100),quitbutt.rect)
          screen.blit(loadbutt.font.render(("Load Game"),True,(155,155,155)),(200,250))
          screen.blit(newbutt.font.render(("New Game"),True,(155,155,155)),(200,300))
          screen.blit(quitbutt.font.render(("Quit Game"),True,(155,155,155)),(200,350))
          pygame.display.flip()

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def newgame():
     Desire="Name"
     Name=screeninput(Desire)
     ID=random.randint(0,1000000000)
     LVL=1
     Strength=10
     Defense=10
     Health=20
     Speed=10
     EXP=0
     Points=0
     Coins=0
     Inventory=[]
     rungame(Name,ID,LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory)

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def savegame(Name,ID,LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
     NameID=Name+str(ID)
     saves=[]
     count=0
     files=open("files.txt","r")
     for i in files:
          i=i.replace("\r","")
          i=i.replace("\n","")
          if (i!=""):
               saves.append(i)
               if i==NameID:
                    count=1
     files.close()
     files=open("files.txt","w")
     for i in saves:
          files.write(i+"\n")
     if count==0:
          files.write(NameID+"\n")
     files.close()
     filename=NameID+".txt"
     savefile = open(filename, "w")
     savefile.write(Name+"\n"+str(ID)+"\n"+str(LVL)+"\n"+str(Strength)+"\n"+str(Defense)+"\n"+str(Health)+"\n"+str(Speed)+"\n"+str(int(EXP))+"\n"+str(Points)+"\n"+str(Coins))
     savefile.close()
     invfilename=NameID+"inv.txt"
     invfile = open(invfilename, "w")
     for i in Inventory:
          invfile.write(i+"\n")
     invfile.close()
     saved=1
     while saved==1:
          saveimg=pygame.image.load('savedpng.png')
          savepop=Button(0,0,0,0)
          savebutton=Button(198,273,104,29)
          screen.blit(saveimg,savepop.rect)
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          if savebutton.rect.colliderect(mouse.rect):
               saved=0
          pygame.display.flip()
     
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def loadgame():
     class Textbox(object):
          def __init__(self,x,y,a,b):
               self.rect=pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class ScreenButton(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     lmenimg=pygame.image.load("loadmenu.png")
     loadimg=pygame.image.load("loadbutton.png")
     deleteimg=pygame.image.load("deletebutton.png")
     upimg=pygame.image.load('upbutton.png')
     downimg=pygame.image.load('downbutton.png')
     upbutt=ScreenButton(35,235,30,30)
     downbutt=ScreenButton(435,235,30,30)
     load1=ScreenButton(340,55,40,40)
     load2=ScreenButton(340,205,40,40)
     load3=ScreenButton(340,355,40,40)
     delete1=ScreenButton(340,105,40,40)
     delete2=ScreenButton(340,255,40,40)
     delete3=ScreenButton(340,405,40,40)
     saves=[]
     text=Textbox(0,0,10,10)
     files=open("files.txt","r")
     for i in files:
          i=i.replace("\r","")
          i=i.replace("\n","")
          if (i!=""):
               saves.append(i)
     files.close()
     Scroll=0
     loading=1
     loaded=1
     while loading==1:
          mouse.rect.x,mouse.rect.y=0,0
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          screen.fill((0,0,0))
          if downbutt.rect.colliderect(mouse.rect):
                    if Scroll<(len(saves)-3):
                         Scroll=Scroll+1
          if upbutt.rect.colliderect(mouse.rect):
               if Scroll>0:
                    Scroll=Scroll-1
          Cancel=pygame.image.load('cancelbutton.png')
          cancelbutt=ScreenButton(420,50,30,30)
          screen.blit(lmenimg,back.rect)
          screen.blit(Cancel,cancelbutt.rect)
          screen.blit(downimg,downbutt.rect)
          screen.blit(upimg,upbutt.rect)
          if cancelbutt.rect.colliderect(mouse.rect):
               loading=0
               loaded=0
          if len(saves)>0:
               loader1=saves[Scroll].rstrip(string.digits)
               if load1.rect.colliderect(mouse.rect):
                    loadname=saves[Scroll]
                    loading=0
               if delete1.rect.colliderect(mouse.rect):
                    deletename=saves[Scroll]+".txt"
                    if os.path.exists(deletename):
                         os.remove(deletename)
                         deleteinvname=saves[Scroll]+"inv.txt"
                         if os.path.exists(deleteinvname):
                              os.remove(deleteinvname)
                    saves.remove(saves[Scroll])
                    if Scroll>(len(saves)-3):
                         if Scroll>0:
                              Scroll=Scroll-1
               screen.blit(loadimg,load1.rect)
               screen.blit(deleteimg,delete1.rect)
               screen.blit(text.font.render((loader1),True,(0,0,0)),(120,70))
          if len(saves)>1:
               loader2=saves[Scroll+1].rstrip(string.digits)
               if load2.rect.colliderect(mouse.rect):
                    loadname=saves[(Scroll+1)]
                    loading=0
               if delete2.rect.colliderect(mouse.rect):
                    deletename=saves[Scroll+1]+".txt"
                    if os.path.exists(deletename):
                         os.remove(deletename)
                    saves.remove(saves[(Scroll+1)])
                    if Scroll>(len(saves)-3):
                         if Scroll>0:
                              Scroll=Scroll-1
               screen.blit(loadimg,load2.rect)
               screen.blit(deleteimg,delete2.rect)
               screen.blit(text.font.render((loader2),True,(0,0,0)),(120,220))
          if len(saves)>2:
               loader3=saves[(Scroll+2)].rstrip(string.digits)
               if load3.rect.colliderect(mouse.rect):
                    loadname=saves[Scroll+2]
                    loading=0
               if delete3.rect.colliderect(mouse.rect):
                    deletename=saves[Scroll+1]+".txt"
                    if os.path.exists(deletename):
                         os.remove(deletename)
                    saves.remove(saves[Scroll+2])
                    if Scroll>(len(saves)-3):
                         if Scroll>0:
                              Scroll=Scroll-1
               screen.blit(loadimg,load3.rect)
               screen.blit(deleteimg,delete3.rect)
               screen.blit(text.font.render((loader3),True,(0,0,0)),(120,370))
          if len(saves)==0:
               while loading==1:
                    mouse.rect.x,mouse.rect.y=0,0
                    popup=ScreenButton(0,0,0,0)
                    popupbutt=ScreenButton(200,275,100,25)
                    for event in pygame.event.get():
                         if event.type==pygame.MOUSEBUTTONDOWN:
                              mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
                    if popupbutt.rect.colliderect(mouse.rect):
                         loaded=0
                         loading=0
                    nosave=pygame.image.load("Nosaves.png")
                    screen.blit(nosave,popup.rect)
                    pygame.display.flip()
          pygame.display.flip()
     files=open("files.txt","w")
     for i in saves:
          files.write(i+"\n")
     files.close()
     if loaded==1:
          loadinvname=loadname+"inv.txt"
          loadname=loadname+".txt"
          playerdata=[]
          playerfile=open(loadname,"r")
          for i in playerfile:
               i=i.replace("\r","")
               i=i.replace("\n","")
               if (i!=""):
                    playerdata.append(i)
          Inventory=[]
          invfile=open(loadinvname,"r")
          for i in invfile:
               i=i.replace("\r","")
               i=i.replace("\n","")
               if (i!=""):
                    Inventory.append(i)
          Name=playerdata[0]
          ID=playerdata[1]
          LVL=int(playerdata[2])
          Strength=int(playerdata[3])
          Defense=int(playerdata[4])
          Health=int(playerdata[5])
          Speed=int(playerdata[6])
          EXP=int(playerdata[7])
          Points=int(playerdata[8])
          Coins=int(playerdata[9])
          rungame(Name,ID,LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory)
          
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
     
def rungame(Name,ID,LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory):
     class BoardButton(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Textbox(object):
          def __init__(self,x,y,a,b):
               self.rect=pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
                         
     play=1
     display=0
     Scroll=0
     Paused=0
     New=0
     Profile=("Profile - " + Name)
     displays=["Dungeon Board", "Shop", Profile]
     while play==1:
          if New==0:
               pygame.mixer.pre_init(44100,16,2,4096)
               pygame.mixer.music.load('Track Outside.mp3')
               pygame.mixer.music.set_volume(100)
               pygame.mixer.music.play(-1)
               New=1
          mouse.rect.x,mouse.rect.y=0,0
          screen.fill((88,88,88))
          menimg=pygame.image.load('Menubar.png')
          leftimg=pygame.image.load('leftbutton.png')
          rightimg=pygame.image.load('rightbutton.png')
          leftbutt=BoardButton(30,450,30,30)
          rightbutt=BoardButton(440,450,30,30)
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          if display==0:
               Dungeons=["Valdemeir's Tomb", "Barradock Mines", "Fort of Darnuum","Dead Forest", "Dravma Cove"]
               upbutt=BoardButton(160,340,30,30)
               downbutt=BoardButton(310,340,30,30)
               ply1=BoardButton(325,112.5,50,50)
               ply2=BoardButton(325,187.5,50,50)
               ply3=BoardButton(325,262.5,50,50)
               text1=Textbox(125,112.5,10,10)
               bar=Textbox(0,430,500,70)
               if downbutt.rect.colliderect(mouse.rect):
                    if Scroll<(len(Dungeons)-3):
                         Scroll=Scroll+1
               if upbutt.rect.colliderect(mouse.rect):
                    if Scroll>0:
                         Scroll=Scroll-1
               disimg=pygame.image.load('Scrollingboard.png')
               upimg=pygame.image.load('upbutton.png')
               downimg=pygame.image.load('downbutton.png')
               playimg=pygame.image.load('playbutton.png')
               if ply1.rect.colliderect(mouse.rect):
                    LMIN=Scroll*10
                    LMAX=(Scroll*10)+9
                    LVL,Strength,Defense,Health,Speed,EXP,Points,Coins=dungeon(LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory,LMIN,LMAX)
                    New=0
               if ply2.rect.colliderect(mouse.rect):
                    LMIN=(Scroll+1)*10
                    LMAX=((Scroll+1)*10)+9
                    LVL,Strength,Defense,Health,Speed,EXP,Points,Coins=dungeon(LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory,LMIN,LMAX)
                    New=0
               if ply3.rect.colliderect(mouse.rect):
                    LMIN=(Scroll+2)*10
                    LMAX=((Scroll+2)*10)+9
                    LVL,Strength,Defense,Health,Speed,EXP,Points,Coins=dungeon(LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory,LMIN,LMAX)
                    New=0
               screen.blit(disimg,back.rect)
               screen.blit(upimg,upbutt.rect)
               screen.blit(downimg,downbutt.rect)
               screen.blit(playimg,ply1.rect)
               screen.blit(playimg,ply2.rect)
               screen.blit(playimg,ply3.rect)
               screen.blit(text1.font.render((Dungeons[Scroll]),True,(0,0,0)),(115,112.5))
               screen.blit(text1.font.render((Dungeons[Scroll+1]),True,(0,0,0)),(115,187.5))
               screen.blit(text1.font.render((Dungeons[Scroll+2]),True,(0,0,0)),(115,262.5))
               Range="LVL: " + str(Scroll*10) + " - " + str((Scroll*10)+9) 
               screen.blit(text1.font.render((Range),True,(0,0,0)),(115,142.5))
               Range="LVL: " + str((Scroll+1)*10) + " - " + str(((Scroll+1)*10)+9)
               screen.blit(text1.font.render((Range),True,(0,0,0)),(115,217.5))
               Range="LVL: " + str((Scroll+2)*10) + " - " + str(((Scroll+2)*10)+9)
               screen.blit(text1.font.render((Range),True,(0,0,0)),(115,292.5))
          if display==1:
               enter=BoardButton(175,235,150,30)
               pygame.draw.rect(screen,(155,155,155),enter.rect)
               entertext=Centertext("Enter Shop", (250,250))
               entertext.draw(screen)
               title=Centertext("The general goods store", (250,150))
               title.draw(screen)
               if enter.rect.colliderect(mouse.rect):
                    Coins,Inventory=Shopping(Coins,Inventory)
          if display==2:
               if Points>0:
                    plusbutt=pygame.image.load('plusbutton.png')
                    plus1=BoardButton(30,115,40,40)
                    plus2=BoardButton(30,165,40,40)
                    plus3=BoardButton(30,215,40,40)
                    plus4=BoardButton(30,265,40,40)
                    if plus1.rect.colliderect(mouse.rect):
                         Points=Points-1
                         Strength=Strength+1
                    if plus2.rect.colliderect(mouse.rect):
                         Points=Points-1
                         Defense=Defense+1
                    if plus3.rect.colliderect(mouse.rect):
                         Points=Points-1
                         Health=Health+1
                    if plus4.rect.colliderect(mouse.rect):
                         Points=Points-1
                         Speed=Speed+1
                    screen.blit(plusbutt,plus1.rect)
                    screen.blit(plusbutt,plus2.rect)
                    screen.blit(plusbutt,plus3.rect)
                    screen.blit(plusbutt,plus4.rect)
               Invbutt=BoardButton(325,250,150,30)
               pygame.draw.rect(screen,(100,100,100),Invbutt.rect)
               Invtext = Centertext("Inventory", (400,267))
               Invtext.draw(screen)
               if Invbutt.rect.colliderect(mouse.rect):
                    Inventory=Viewinventory(Inventory)
               data=Textbox(0,0,0,0)
               output="Name: " + Name
               screen.blit(data.font.render((output),True,(0,0,0)),(100,25))
               output="Coins: " + str(Coins)
               screen.blit(data.font.render((output),True,(0,0,0)),(325,25))
               output="Level: " + str(LVL)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,75))
               output="Strength: " + str(Strength)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,125))
               output="Defense: " + str(Defense)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,175))
               output="Health: " + str(Health)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,225))
               output="Speed: " + str(Speed)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,275))
               EXPTOLVL=(50+100*LVL+1.2**LVL)-((50+100*LVL+1.2**LVL)%1)
               output="Experience: " + str(EXP)+"/"+str(EXPTOLVL)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,325))
               output="Stat Points: " + str(Points)
               screen.blit(data.font.render((output),True,(0,0,0)),(100,375))
          if leftbutt.rect.colliderect(mouse.rect):
               if display==0:
                    display=(len(displays)-1)
               else:
                    display=display-1
          if rightbutt.rect.colliderect(mouse.rect):
               if display<(len(displays)-1):
                    display=display+1
               else:
                    display=0
          user_input = pygame.key.get_pressed()
          if user_input[pygame.K_p]:
               Paused=1
               
          while Paused==1:
               mouse.rect.x,mouse.rect.y=0,0
               for event in pygame.event.get():
                    if event.type==pygame.MOUSEBUTTONDOWN:
                         mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
               resume=BoardButton(150,85,200,30)
               resumetext = Centertext("Resume Game", (250,105))
               if resume.rect.colliderect(mouse.rect):
                    Paused=0
               save=BoardButton(150,235,200,30)
               savetext = Centertext("Save Game", (250,255))
               if save.rect.colliderect(mouse.rect):
                    savegame(Name,ID,LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory)
               leave=BoardButton(150,385,200,30)
               leavetext = Centertext("Exit Game", (250,405))
               if leave.rect.colliderect(mouse.rect):
                    Paused=0
                    play=0
                    pygame.mixer.music.stop()
               mouse.rect.x,mouse.rect.y=0,0
               pausing=BoardButton(75,25,0,0)
               pausemenu=pygame.image.load('Pause.png')
               screen.blit(pausemenu,pausing.rect)
               pygame.draw.rect(screen,(150,150,150),resume.rect)
               pygame.draw.rect(screen,(150,150,150),save.rect)
               pygame.draw.rect(screen,(150,150,150),leave.rect)
               resumetext.draw(screen)
               savetext.draw(screen)
               leavetext.draw(screen)
               pygame.display.flip()
          screen.blit(menimg,bar.rect)
          screen.blit(leftimg,leftbutt.rect)
          screen.blit(rightimg,rightbutt.rect)
          scene = Centertext(displays[display], (250,470))
          scene.draw(screen)
          pygame.display.flip()
          
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Shopping(Coins,Inventory):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Item(object):
          def __init__(self,x,y,name):
               Items.append(self)
               Itemnames.append(name)
               self.rect = pygame.Rect(x,y,40,40)
               self.font=pygame.font.SysFont('Showcard Gothic',10)
     class Smallertext:
          def __init__(self, text, (x,y)):
             self.x = x
             self.y = y
             font = pygame.font.SysFont("Showcard Gothic", 15)
             self.txt = font.render(text, True, (0,0,0))
             self.size = font.size(text)
          def draw(self, screen):
             drawX = self.x - (self.size[0] / 2.)
             drawY = self.y - (self.size[1] / 2.)
             coords = (drawX, drawY)
             screen.blit(self.txt, coords)
             
     shop=pygame.image.load('shop.png')
     board=Button(0,0,0,0)
     stock=[]
     shopfile=open('shop.txt',"r")
     for i in shopfile:
          i=i.replace("\r","")
          i=i.replace("\n","")
          if (i!=""):
               stock.append(i)
     Viewing=1
     Selected=0
     Wait=30
     while Viewing==1:
          Items=[]
          Itemnames=[]
          screen.fill((158,158,158))
          screen.blit(shop,board.rect)
          Cancel=pygame.image.load('cancelbutton.png')
          cancelbutt=Button(420,50,30,30)
          screen.blit(Cancel,cancelbutt.rect)
          buybutton=Button(355,250,40,40)
          buy=pygame.image.load('buybutton.png')
          Count=0
          for i in stock:
               Item((70+((Count)%3)*60),(80+((Count)/3)*60),i)
               Count=Count+1
          Locate=0
          for Ite in Items:
               image=Itemnames[Locate]+".png"
               Itemimg=pygame.image.load(image)
               screen.blit(Itemimg,Ite.rect)
               Locate=Locate+1
          mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          for event in pygame.event.get():
               IteID=0
               for Ite in Items:
                    if event.type==pygame.MOUSEBUTTONDOWN:
                         if Ite.rect.colliderect(mouse.rect):
                              Selected=1
                              Itemdata=[]
                              itemfilename=Itemnames[IteID]+"info.txt"
                              Itemfile=open(itemfilename,"r")
                              for i in Itemfile:
                                   i=i.replace("\r","")
                                   i=i.replace("\n","")
                                   if (i!=""):
                                        Itemdata.append(i)
                              Itemfile.close()
                              Text=Itemdata[1]
                              Name=Itemdata[2]
                              Price=Itemdata[4]
                              Choice=Itemnames[IteID]
                         if cancelbutt.rect.colliderect(mouse.rect):
                              Viewing=0
                         if Selected==1:
                              if buybutton.rect.colliderect(mouse.rect):
                                   if Wait<1:
                                        if Coins>=int(Price):
                                             Coins=Coins-int(Price)
                                             Inventory.append(Choice)
                                             Wait=30
                    IteID=IteID+1
          Wait=Wait-1
          if Selected==1:
               itemboximg=pygame.image.load('itemboxpng.png')
               itembox=Button(125,0,200,150)
               screen.blit(itemboximg,itembox.rect)
               screen.blit(buy,buybutton.rect)
               Nametext=Smallertext(Name,(375,170))
               Nametext.draw(screen)
               Itemtext=Smallertext(Text,(375,200))
               Itemtext.draw(screen)
               Pricetext=Smallertext(("Price: " +Price),(375,230))
               Pricetext.draw(screen)
          Cointext=Centertext(("Your coins: " + str(Coins)),(375,400))
          Cointext.draw(screen)
          pygame.display.flip()
     return Coins, Inventory
          
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def mazegen():
     width=random.randint(8,12)
     length=random.randint(8,12)
     level=[]
     layout = [["X" for x in range(width)] for y in range(length)]
     #Start and end set
     XCO1=random.randint(0,width-1)
     YCO1=random.randint(0,length-1)
     XCO2,YCO2=XCO1,YCO1
     while (XCO2<XCO1+3) and (XCO2>XCO1-3):
          XCO2=random.randint(0,width-1)
     while (YCO2<YCO1+3) and (YCO2>YCO1-3):
          YCO2=random.randint(0,length-1)
     #Confirm path
     Changex,Changey=XCO1,YCO1
     layout[YCO1][XCO1]="O"
     layout[YCO2][XCO2]="O"
     while (Changex!=XCO2) or (Changey!=YCO2):
         route=random.randint(0,1)
         #Moves along x
         if route==0:
             if Changex<XCO2:
                 Changex=Changex+1
             if Changex>XCO2:
                 Changex=Changex-1
         #Moves along y
         if route==1:
             if Changey<YCO2:
                 Changey=Changey+1
             if Changey>YCO2:
                 Changey=Changey-1
         layout[Changey][Changex]="O"
     #Space plotter
     for x in range(width):
         for y in range(length):
             Count=0
             if x<width-1:
                 if layout[y][x+1]=="O":
                     Count=Count+1
             if x>0:
                 if layout[y][x-1]=="O":
                     Count=Count+1
             if y<length-1:
                 if layout[y+1][x]=="O":
                     Count=Count+1
             if y>0:
                 if layout[y-1][x]=="O":
                     Count=Count+1
             chance=random.randint((5-Count),7)
             if chance<=5:
                 layout[y][x]="O"

     x,y=XCO1,YCO1
     Floodroute=[]
     Floodroute=Flood(Floodroute,x,y,layout,width,length)
     for x in range(width):
         for y in range(length):
              Exist=0
              for i in range(len(Floodroute)):
                   if layout[y][x]=="O":
                        if (Floodroute[i][0]==x) and (Floodroute[i][1]==y):
                             Exist=Exist+1
              if Exist==0:
                   layout[y][x]="X"
     #Shaping
     level=layout
     for x in range(width):
         for y in range(length):
              if layout[y][x]=="O":
                   if (x<width-1) and (layout[y][x+1]!="X"):
                        if (x>0) and (layout[y][x-1]!="X"):
                             if (y<length-1) and (layout[y+1][x]!="X"):
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="E"
                                  else:
                                       level[y][x]="F"
                             else:
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="G"
                                  else:
                                       level[y][x]="L"
                        else:
                             if (y<length-1) and (layout[y+1][x]!="X"):
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="H"
                                  else:
                                       level[y][x]="C"
                             else:
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="K"
                                  else:
                                       level[y][x]="M"
                   else:
                        if (x>0) and (layout[y][x-1]!="X"):
                             if (y<length-1) and (layout[y+1][x]!="X"):
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="I"
                                  else:
                                       level[y][x]="B"
                             else:
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="J"
                                  else:
                                       level[y][x]="N"
                        else:
                             if (y<length-1) and (layout[y+1][x]!="X"):
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="D"
                                  else:
                                       level[y][x]="A"
                             else:
                                  if (y>0) and (layout[y-1][x]!="X"):
                                       level[y][x]="O"
                                  else:
                                       level[y][x]="X"
                                       
     return level, XCO1, YCO1, XCO2, YCO2

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Flood(Floodroute,x,y,layout,width,length):
     Pholder=[x,y]
     Uphole=[x,y-1]
     Downhole=[x,y+1]
     Lefthole=[x-1,y]
     Righthole=[x+1,y]
     Checking=0
     Upcheck=0
     Downcheck=0
     Leftcheck=0
     Rightcheck=0
     for i in range(len(Floodroute)):
          if Floodroute[i]==Uphole:
               Upcheck=1
          if Floodroute[i]==Downhole:
               Downcheck=1
          if Floodroute[i]==Lefthole:
               Leftcheck=1
          if Floodroute[i]==Righthole:
               Rightcheck=1
          if Floodroute[i]==Pholder:
               Checking=Checking+1
     if Checking==0:
          Floodroute.append(Pholder)
     #Up
     if (y>0) and (layout[y-1][x]=="O") and (Upcheck==0):
          Floodroute=Flood(Floodroute,x,y-1,layout,width,length)
     #Down
     if (y<length-1) and (layout[y+1][x]=="O") and (Downcheck==0):
          Floodroute=Flood(Floodroute,x,y+1,layout,width,length)
     #Left
     if (x>0) and (layout[y][x-1]=="O") and (Leftcheck==0):
          Floodroute=Flood(Floodroute,x-1,y,layout,width,length)
     #Right
     if (x<width-1) and (layout[y][x+1]=="O") and (Rightcheck==0):
          Floodroute=Flood(Floodroute,x+1,y,layout,width,length)
     return Floodroute

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Combat (Strength, Defense, Health, Speed, Currhealth, LMIN, LMAX, EXP, Coins, Inventory):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Healthbar(object):
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Icon(object):
          def __init__(self,x,y): 
               self.rect = pygame.Rect(x,y,100,200)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Textbox(object):
          def __init__(self,x,y,a,b):
               self.rect=pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     combatback=pygame.image.load('CombatScreen.png')
     combatlog=pygame.image.load('CombatBar.png')
     arrowimg=pygame.image.load('arrow.png')
     name, monimg, Monhealth, Monspeed, Monstrength, Mondefense=MonsterType(LMIN)
     Currmhealth=Monhealth
     enemy=Icon(300,100)
     hero=Icon(100,100)
     bar=Textbox(0,430,500,70)
     text=Textbox(0,0,0,0)
     Flash=500
     Lit=1
     Playerdefend=0
     Enemydefend=0
     arrow=Button(450,450,30,30)
     Fighting=True
     Starting=True
     while Fighting==True:
          monperc=(Currmhealth*100)/Monhealth
          playerperc=(Currhealth*100)/Health
          if playerperc==100:
               playerperc=playerperc+1
          if monperc==100:
               monperc=monperc+1
          screen.fill((0,0,0))
          screen.blit(combatback,back.rect)
          screen.blit(combatlog,bar.rect)
          screen.blit(monimg,enemy.rect)
          heroimg=pygame.image.load('Hero.png')
          screen.blit(heroimg,hero.rect)
          if playerperc!=0:
               playhealth=Healthbar(201-playerperc,302,playerperc,30)
               pygame.draw.rect(screen,(255,0,0),playhealth.rect)
          if monperc!=0:
               enemyhealth=Healthbar(401-monperc,302,monperc,30)
               pygame.draw.rect(screen,(255,0,0),enemyhealth.rect)
          while Starting==True:
               for event in pygame.event.get():
                    if event.type==pygame.MOUSEBUTTONDOWN:
                         mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
               if bar.rect.colliderect(mouse.rect):
                    Starting=False
               screen.blit(combatlog,bar.rect)
               screen.blit(text.font.render(("You are being attacked by a"),True,(0,0,0)),(20,440))
               screen.blit(text.font.render((name),True,(0,0,0)),(20,470))
               Usage="Null"
               Modifier=0
               Target="Null"
               Itemname="Null"
               if Lit==1:
                    if Flash==0:
                         Flash=500
                         Lit=0
                    screen.blit(arrowimg,arrow.rect)
               if (Lit==0) and (Flash==0):
                    Flash=500
                    Lit=1
               Flash=Flash-1
               pygame.display.flip()
          if Speed>Monspeed:
               Majority=0
               Turns=Speed/Monspeed
          else:
               Majority=1
               Turns=Monspeed/Speed
          for i in range(0,Turns):
               if Fighting==True:
                    #PLAYER TURN
                    if Majority==0:
                         Notitem=0
                         while Notitem==0:
                              result=PlayerTurn()
                              if result=="Item":
                                   Inventory,Success,Usage,Modifier,Target,Itemname=Itemuse(Inventory,Currhealth,Health,Currmhealth)
                                   if Success==True:
                                        Notitem=2
                              else:
                                   Notitem=1
                         Output1,Output2,Playerdefend,Enemydefend,Currmhealth,Health,Currhealth,result=Playerresult(result,Playerdefend,Enemydefend,Strength,Defense,Currhealth,Health,Monstrength,Mondefense,Currmhealth,name,Speed,Monspeed,Usage,Modifier,Target,Itemname)
                         Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
                         if result=="Flee":
                              Fighting=False
                         if Currmhealth==0:
                              Fighting=False
                              EXP=EXP+(random.randint(0,50))+50+LMIN*10
                              Coins=Coins+random.randint(3,5)+20*LMIN
                              Output1=name+" has been defeated!"
                              Output2=""
                              Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
                    #ENEMY TURN
                    if Majority==1:
                         result=EnemyTurn(Currmhealth,Monhealth,name)
                         Output1,Output2,Playerdefend,Enemydefend,Currhealth,result=Enemyresult(result,Playerdefend,Enemydefend,Strength,Defense,Currhealth,Monstrength,Mondefense,Currmhealth,name,Speed,Monspeed)
                         Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
                         if result=="Flee":
                              Fighting=False
                         if Currhealth==0:
                              Fighting=False
                              Output1="You have been defeated!"
                              Output2=""
                              Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
          if Fighting==True:
               #ENEMY TURN
               if Majority==0:
                    result=EnemyTurn(Currmhealth,Monhealth,name)
                    Output1,Output2,Playerdefend,Enemydefend,Currhealth,result=Enemyresult(result,Playerdefend,Enemydefend,Strength,Defense,Currhealth,Monstrength,Mondefense,Currmhealth,name,Speed,Monspeed)
                    Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
                    if result=="Flee":
                         Fighting=False
                    if Currhealth==0:
                         Fighting=False
                         Output1="You have been defeated!"
                         Output2=""
                         Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
               #PLAYER TURN
               if Majority==1:
                    Notitem=0
                    while Notitem==0:
                         result=PlayerTurn()
                         if result=="Item":
                              Inventory,Success,Usage,Modifier,Target,Itemname=Itemuse(Inventory,Currhealth,Health,Currmhealth)
                              if Success==True:
                                   Notitem=2
                         else:
                              Notitem=1
                    Output1,Output2,Playerdefend,Enemydefend,Currmhealth,Health,Currhealth,result=Playerresult(result,Playerdefend,Enemydefend,Strength,Defense,Currhealth,Health,Monstrength,Mondefense,Currmhealth,name,Speed,Monspeed,Usage,Modifier,Target,Itemname)
                    Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
                    if result=="Flee":
                         Fighting=False
                    if Currmhealth==0:
                         Fighting=False
                         EXP=EXP+(random.randint(0,50))+50+LMIN*10
                         Coins=Coins+random.randint(3,5)+2*LMIN
                         Output1=name+" has been defeated!"
                         Output2=""
                         Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg)
     return Currhealth, EXP, Coins, Inventory

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Viewinventory(Inventory):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Item(object):
          def __init__(self,x,y,name):
               Items.append(self)
               Itemnames.append(name)
               self.rect = pygame.Rect(x,y,40,40)
               self.font=pygame.font.SysFont('Showcard Gothic',10)
               
     menu=pygame.image.load('itemmenu.png')
     upimg=pygame.image.load('upbutton.png')
     downimg=pygame.image.load('downbutton.png')
     board=Button(150,50,200,400)
     upbutt=Button(60,235,30,30)
     downbutt=Button(410,235,30,30)
     Viewing=1
     Scroll=0
     while Viewing==1:
          Items=[]
          Itemnames=[]
          screen.fill((158,158,158))
          Cancel=pygame.image.load('cancelbutton.png')
          cancelbutt=Button(420,50,30,30)
          screen.blit(Cancel,cancelbutt.rect)
          screen.blit(menu,board.rect)
          screen.blit(upimg,upbutt.rect)
          screen.blit(downimg,downbutt.rect)
          Count=0
          for i in Inventory:
               if Count>=Scroll*3:
                    if Count<((Scroll*3)+18):
                         Item((170+((Count)%3)*60),(80+(((Count)/3)-Scroll)*60),i)
               Count=Count+1
          Locate=0
          for Ite in Items:
               image=Itemnames[Locate]+".png"
               Itemimg=pygame.image.load(image)
               screen.blit(Itemimg,Ite.rect)
               Locate=Locate+1
          mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    IteID=0
                    for Ite in Items:
                         if Ite.rect.colliderect(mouse.rect):
                              Response=Viewitem(Itemnames[IteID])
                              if Response=="Delete":
                                   Inventory.pop(IteID)
                         IteID=IteID+1
                    if downbutt.rect.colliderect(mouse.rect):
                         if (Scroll*3+18)<len(Inventory):
                              Scroll=Scroll+1
                    if upbutt.rect.colliderect(mouse.rect):
                         if Scroll>0:
                              Scroll=Scroll-1
                    if cancelbutt.rect.colliderect(mouse.rect):
                         Viewing=0
          pygame.display.flip()
     return Inventory
          
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Viewitem(Item):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     Itemf=Item+"info.txt"
     Itemdata=[]
     Itemfile=open(Itemf,"r")
     for i in Itemfile:
          i=i.replace("\r","")
          i=i.replace("\n","")
          if (i!=""):
               Itemdata.append(i)
     Itemfile.close()
     Text1=Itemdata[0]
     Text2=Itemdata[1]
     Name=Itemdata[2]
     Image=Itemdata[3]
     Img=pygame.image.load(Image)
     Board=Button(75,25,350,450)
     Iteimg=Button(230,80,40,40)
     Boardimg=pygame.image.load('Pause.png')
     Cancelimg=pygame.image.load('cancelbutton.png')
     Cancelbutt=Button(100,50,40,40)
     Deleteimg=pygame.image.load('deletebutton.png')
     Deletebutt=Button(360,50,40,40)
     Response="Null"
     Viewing=1
     while Viewing==1:
          mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    if Cancelbutt.rect.colliderect(mouse.rect):
                         Viewing=0
                    if Deletebutt.rect.colliderect(mouse.rect):
                         Viewing=0
                         Response="Delete"
          screen.fill((0,0,0))
          screen.blit(Boardimg,Board.rect)
          screen.blit(Cancelimg,Cancelbutt.rect)
          screen.blit(Deleteimg,Deletebutt.rect)
          screen.blit(Img,Iteimg.rect)
          posttext1 = Centertext(Text1, (250,300))
          posttext1.draw(screen)
          posttext2 = Centertext(Text2, (250,400))
          posttext2.draw(screen)
          nametext = Centertext(Name, (250,200))
          nametext.draw(screen)
          pygame.display.flip()
     return Response
          
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Itemuse(Inventory,Currhealth,Health,Currmhealth):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Item(object):
          def __init__(self,x,y,name):
               Items.append(self)
               Itemnames.append(name)
               self.rect = pygame.Rect(x,y,40,40)
               self.font=pygame.font.SysFont('Showcard Gothic',10)
               
     menu=pygame.image.load('itemmenu.png')
     upimg=pygame.image.load('upbutton.png')
     downimg=pygame.image.load('downbutton.png')
     board=Button(150,50,200,400)
     upbutt=Button(60,235,30,30)
     downbutt=Button(410,235,30,30)
     Selecting=1
     Scroll=0
     Success=False
     while Selecting==1:
          Items=[]
          Itemnames=[]
          screen.fill((158,158,158))
          Cancel=pygame.image.load('cancelbutton.png')
          cancelbutt=Button(420,50,30,30)
          screen.blit(Cancel,cancelbutt.rect)
          screen.blit(menu,board.rect)
          screen.blit(upimg,upbutt.rect)
          screen.blit(downimg,downbutt.rect)
          Count=0
          for i in Inventory:
               if Count>=Scroll*3:
                    if Count<((Scroll*3)+18):
                         Item((170+((Count)%3)*60),(80+(((Count)/3)-Scroll)*60),i)
               Count=Count+1
          Locate=0
          for Ite in Items:
               image=Itemnames[Locate]+".png"
               Itemimg=pygame.image.load(image)
               screen.blit(Itemimg,Ite.rect)
               Locate=Locate+1
          mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    IteID=0
                    for Ite in Items:
                         if Ite.rect.colliderect(mouse.rect):
                              Usage,Modifier,Target,Name=Usingitem(Itemnames[IteID],Currhealth,Health)
                              if Usage!="Null":
                                   Success=True
                                   Inventory.pop(IteID)
                                   return Inventory,Success,Usage,Modifier,Target,Name
                         IteID=IteID+1
                    if downbutt.rect.colliderect(mouse.rect):
                         if (Scroll*3+18)<len(Inventory):
                              Scroll=Scroll+1
                    if upbutt.rect.colliderect(mouse.rect):
                         if Scroll>0:
                              Scroll=Scroll-1
                    if cancelbutt.rect.colliderect(mouse.rect):
                         Selecting=0
          pygame.display.flip()
     return Inventory,Success,Usage,Modifier,Target,Name
     

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Usingitem(Item, Currhealth, Health):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     Itemf=Item+"info.txt"
     Itemdata=[]
     Itemfile=open(Itemf,"r")
     for i in Itemfile:
          i=i.replace("\r","")
          i=i.replace("\n","")
          if (i!=""):
               Itemdata.append(i)
     Itemfile.close()
     Text1=Itemdata[0]
     Text2=Itemdata[1]
     Name=Itemdata[2]
     Image=Itemdata[3]
     Usage=Itemdata[5]
     if Usage=="Heal":
          if Currhealth==Health:
               Usage="Null"
     Modifier=0
     Target="Null"
     if Usage!="Null":
          Modifier=int(Itemdata[6])
          Target=Itemdata[7]
     Img=pygame.image.load(Image)
     Board=Button(75,25,350,450)
     Iteimg=Button(230,80,40,40)
     Boardimg=pygame.image.load('Pause.png')
     Cancelimg=pygame.image.load('cancelbutton.png')
     Cancelbutt=Button(100,50,40,40)
     if Usage!="Null":
          Useimg=pygame.image.load('usebutton.png')
          Usebutt=Button(360,50,40,40)
     Viewing=1
     while Viewing==1:
          mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    if Cancelbutt.rect.colliderect(mouse.rect):
                         Viewing=0
                         Usage="Null"
                    if Usebutt.rect.colliderect(mouse.rect):
                         Viewing=0
          screen.fill((0,0,0))
          screen.blit(Boardimg,Board.rect)
          screen.blit(Cancelimg,Cancelbutt.rect)
          if Usage!="Null":
               screen.blit(Useimg,Usebutt.rect)
          screen.blit(Img,Iteimg.rect)
          posttext1 = Centertext(Text1, (250,300))
          posttext1.draw(screen)
          posttext2 = Centertext(Text2, (250,400))
          posttext2.draw(screen)
          nametext = Centertext(Name, (250,200))
          nametext.draw(screen)
          pygame.display.flip()
     return Usage,Modifier,Target,Name

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Outputresult(Output1,Output2,Currhealth,Health,Currmhealth,Monhealth,monimg):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Healthbar(object):
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Icon(object):
          def __init__(self,x,y): 
               self.rect = pygame.Rect(x,y,100,200)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Textbox(object):
          def __init__(self,x,y,a,b):
               self.rect=pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     combatback=pygame.image.load('CombatScreen.png')
     combatlog=pygame.image.load('CombatBar.png')
     arrowimg=pygame.image.load('arrow.png')
     enemy=Icon(300,100)
     hero=Icon(100,100)
     bar=Textbox(0,430,500,70)
     text=Textbox(0,0,0,0)
     Lit=1
     Flash=500
     arrow=Button(450,450,30,30)
     moveresult=True
     mouse.rect.x,mouse.rect.y=0,0
     while moveresult==True:
          monperc=(Currmhealth*100)/Monhealth
          playerperc=(Currhealth*100)/Health
          if playerperc==100:
               playerperc=playerperc+1
          if monperc==100:
               monperc=monperc+1
          screen.fill((0,0,0))
          screen.blit(combatback,back.rect)
          screen.blit(combatlog,bar.rect)
          screen.blit(monimg,enemy.rect)
          heroimg=pygame.image.load('Hero.png')
          screen.blit(heroimg,hero.rect)
          if playerperc!=0:
               playhealth=Healthbar(201-playerperc,302,playerperc,30)
               pygame.draw.rect(screen,(255,0,0),playhealth.rect)
          if monperc!=0:
               enemyhealth=Healthbar(401-monperc,302,monperc,30)
               pygame.draw.rect(screen,(255,0,0),enemyhealth.rect)
          screen.blit(text.font.render((Output1),True,(0,0,0)),(20,440))
          if Output2!="": 
               screen.blit(text.font.render((Output2),True,(0,0,0)),(20,470))
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          if bar.rect.colliderect(mouse.rect):
               moveresult=False
          if Lit==1:
               if Flash==0:
                    Flash=500
                    Lit=0
               screen.blit(arrowimg,arrow.rect)
          if (Lit==0) and (Flash==0):
               Flash=500
               Lit=1
          Flash=Flash-1
          pygame.display.flip()

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Playerresult(result,Playerdefend,Enemydefend,Strength,Defense,Currhealth,Health,Monstrength,Mondefense,Currmhealth,name,Speed,Monspeed,Usage,Modifier,Target,Itemname):
     if result=="Fight":
          if Enemydefend==1:
               if Strength>(2*Mondefense):
                    ATTDMG=Strength-(2*Mondefense)
                    Enemydefend=0
               else:
                    ATTDMG=0
               Currmhealth=Currmhealth-(1+ATTDMG)
          else:
               if Strength>Mondefense:
                    ATTDMG=Strength-Mondefense
               else:
                    ATTDMG=0
               Currmhealth=Currmhealth-(2+ATTDMG)
          if Currmhealth<0:
               Currmhealth=0
          Output1="You have dealt "+str(2+ATTDMG)+" damage"
          Output2="to "+name+"!"
     if result=="Defend":
          Playerdefend=1
          Output1="You have successfully defended"
          Output2="yourself!"
     if result=="Flee":
          if Speed*1.2>=Monspeed:
               Output1="You have successfully fled!"
               Output2=""
          else:
               Output1="You have failed to flee"
               Output2=""
               result="FleeFail"
     if result=="Item":
          if Usage=="Heal":
               if Target=="Player":
                    Heals=Modifier
                    if Currhealth+Heals>Health:
                         Heals=Health-Currhealth
                    Currhealth=Currhealth+Heals
                    Output1="You used " + Itemname + "."
                    Output2="You healed " + str(Heals) + "health!"
          if Usage=="Flee":
               result="Flee"
               Output1="You used " + Itemname + "."
               Output2="You have successfully fled!"
          if Usage=="Attack":
               Currmhealth=Currmhealth-Modifier
               if Currmhealth<0:
                    Currmhealth=0
               Output1="You used " + Itemname +"."
               Output2="Dealt " + str(Modifier) + "damage to " + name + "!"
     return Output1,Output2,Playerdefend,Enemydefend,Currmhealth,Health,Currhealth,result

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def Enemyresult(result,Playerdefend,Enemydefend,Strength,Defense,Currhealth,Monstrength,Mondefense,Currmhealth,name,Speed,Monspeed):
     if result=="Fight":
          if Playerdefend==1:
               if Monstrength>(2*Defense):
                    ATTDMG=Monstrength-(2*Defense)
                    Playerdefend=0
               else:
                    ATTDMG=0
               Currhealth=Currhealth-(1+ATTDMG)
          else:
               if Monstrength>Defense:
                    ATTDMG=Monstrength-Defense
               else:
                    ATTDMG=0
               Currhealth=Currhealth-(2+ATTDMG)
          if Currhealth<0:
               Currhealth=0
          Output1=name+" has dealt " +str(2+ATTDMG)
          Output2="damage to you!"
     if result=="Defend":
          Enemydefend=1
          Output1=name+" has defended"
          Output2="themself!"
     if result=="Flee":
          if Monspeed*1.2>=Speed:
               Output1=name+" has fled!"
               Output2=""
          else:
               Output1=name+" failed to flee"
               Output2=""
               result="FleeFail"
               
     return Output1,Output2,Playerdefend,Enemydefend,Currhealth,result

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def PlayerTurn():
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     combatlog=pygame.image.load('CombatBar.png')
     arrowimg=pygame.image.load('arrow.png')
     bar=Button(0,430,500,70)
     fightbutt=Button(20,439,100,22)
     defendbutt=Button(250,439,100,22)
     itembutt=Button(20,469,100,22)
     fleebutt=Button(250,469,100,22)
     fighttext = Centertext("Fight", (70,452))
     defendtext = Centertext("Defend", (300,452))
     itemtext = Centertext("Item", (70,482))
     fleetext = Centertext("Flee", (300,482))
     Lit=1
     Flash=500
     Selecting=True
     while Selecting==True:
          screen.blit(combatlog,bar.rect)
          pygame.draw.rect(screen,(150,150,150),fightbutt.rect)
          pygame.draw.rect(screen,(150,150,150),defendbutt.rect)
          pygame.draw.rect(screen,(150,150,150),itembutt.rect)
          pygame.draw.rect(screen,(150,150,150),fleebutt.rect)
          fighttext.draw(screen)
          defendtext.draw(screen)
          itemtext.draw(screen)
          fleetext.draw(screen)
          mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    if fightbutt.rect.colliderect(mouse.rect):
                         result="Fight"
                         Selecting=False
                    if defendbutt.rect.colliderect(mouse.rect):
                         result="Defend"
                         Selecting=False
                    if itembutt.rect.colliderect(mouse.rect):
                         result="Item"
                         Selecting=False
                    if fleebutt.rect.colliderect(mouse.rect):
                         result="Flee"
                         Selecting=False
          if Lit==1:
               if Flash==0:
                    Flash=500
                    Lit=0
               if fightbutt.rect.colliderect(mouse.rect):
                    arrow=Button(150,435,30,30)
                    screen.blit(arrowimg,arrow.rect)
               if defendbutt.rect.colliderect(mouse.rect):
                    arrow=Button(380,435,30,30)
                    screen.blit(arrowimg,arrow.rect)
               if itembutt.rect.colliderect(mouse.rect):
                    arrow=Button(150,465,30,30)
                    screen.blit(arrowimg,arrow.rect)
               if fleebutt.rect.colliderect(mouse.rect):
                    arrow=Button(380,465,30,30)
                    screen.blit(arrowimg,arrow.rect)
          if (Lit==0) and (Flash==0):
               Flash=500
               Lit=1
          Flash=Flash-1
          mouse.rect.x,mouse.rect.y=0,0
          pygame.display.flip()
     return result
               
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def EnemyTurn(Currenthealth,Maxhealth,MType):
     if MType=='Goblin':
          if ((Currenthealth*100)/Maxhealth-(Currenthealth*100)%Maxhealth)<=20:
               Chance=random.randint(0,8)
               if Chance==8:
                    result="Flee"
               elif ((Chance>4) and (Chance<8)):
                    result="Defend"
               else:
                    result="Fight"
          else:
               Chance=random.randint(0,5)
               if Chance<5:
                    result="Fight"
               else:
                    result="Defend"
     if MType=='Wendigo':
          if ((Currenthealth*100)/Maxhealth-(Currenthealth*100)%Maxhealth)<=10:
               Chance=random.randint(0,9)
               if Chance==9:
                    result="Flee"
               elif ((Chance>6) and (Chance<9)):
                    result="Defend"
               else:
                    result="Fight"
          else:
               Chance=random.randint(0,6)
               if Chance<6:
                    result="Fight"
               else:
                    result="Defend"
     if MType=='Golem':
          if ((Currenthealth*100)/Maxhealth-(Currenthealth*100)%Maxhealth)<=30:
               Chance=random.randint(0,15)
               if Chance==15:
                    result="Flee"
               elif ((Chance>1) and (Chance<15)):
                    result="Defend"
               else:
                    result="Fight"
          else:
               Chance=random.randint(0,7)
               if Chance>6:
                    result="Fight"
               else:
                    result="Defend"
     return result
               
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def MonsterType(LMIN):
     DUN1=['Goblin','Wendigo','Golem']
     Name=random.randint(0,(len(DUN1)-1))
     Name=DUN1[Name]
     Multi=((LMIN/10)*3)
     if Name=='Goblin':
          monimg=pygame.image.load('Goblin.png')
          Monhealth=10+Multi*3
          Monspeed=19+Multi*5
          Monstrength=5+Multi
          Mondefense=3+Multi
     if Name=='Wendigo':
          monimg=pygame.image.load('Wendigo.png')
          Monhealth=10+Multi*3
          Monspeed=9+Multi
          Monstrength=11+Multi*4
          Mondefense=4+Multi*2
     if Name=='Golem':
          monimg=pygame.image.load('Golem.png')
          Monhealth=10+Multi*3
          Monspeed=6+Multi
          Monstrength=8+Multi*2
          Mondefense=12+Multi*4
     return Name, monimg, Monhealth, Monspeed, Monstrength, Mondefense
     
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def dungeon(LVL,Strength,Defense,Health,Speed,EXP,Points,Coins,Inventory,LMIN,LMAX):
     class Button(object): 
          def __init__(self,x,y,a,b): 
               self.rect = pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     class Point(object):
          def __init__(self):
              self.rect=pygame.Rect(380,310,200,100)
              self.font=pygame.font.SysFont('Showcard Gothic',15)

     level, XStart, YStart, XEnd, YEnd=mazegen()
     I1 = pygame.image.load('Corridor.png')
     I2 = pygame.image.load('Dead End.png')
     I3 = pygame.image.load('Left Corner.png')
     I4 = pygame.image.load('Left T.png')
     I5 = pygame.image.load('Right Corner.png')
     I6 = pygame.image.load('Right T.png')
     I7 = pygame.image.load('T Shape.png')
     I8 = pygame.image.load('X Shape.png')
     point=Point()
     XCO,YCO=XStart,YStart
     Wait=0
     Paused=0
     Battleover=0
     LVLed=0
     Currhealth=Health
     Walk=False
     Directions=["West","North","East","South"]
     Direction=0
     ADEC=[I3,I2,I5,I1]
     BDEC=[I4,I3,I5,I6]
     CDEC=[I3,I5,I6,I4]
     DDEC=[I7,I1,I7,I1]
     EDEC=[I8,I8,I8,I8]
     FDEC=[I4,I7,I6,I8]
     GDEC=[I6,I8,I4,I7]
     HDEC=[I7,I6,I8,I4]
     IDEC=[I8,I4,I7,I6]
     JDEC=[I6,I4,I3,I5]
     KDEC=[I5,I6,I4,I3]
     LDEC=[I1,I7,I1,I7]
     MDEC=[I2,I5,I1,I3]
     NDEC=[I1,I3,I2,I5]
     ODEC=[I5,I1,I3,I2]
     footstep=pygame.mixer.Sound("Footstep.mp3")
     pygame.mixer.music.load('Track Cave.mp3')
     pygame.mixer.music.set_volume(100)
     pygame.mixer.music.play(-1)
     Running=True
     while Running==True:
          user_input = pygame.key.get_pressed()
          Row=level[YCO]
          Shape=(Row[XCO])
          if Wait<1:
               events = pygame.event.get()
               for event in events:
                    if event.type == pygame.KEYDOWN:
                         if event.key == pygame.K_w:
                              if Walk==True: 
                                   if Directions[Direction]=="West":
                                        if XCO!=0:
                                             if str(Row[(XCO-1)])!="X":
                                                  XCO=XCO-1
                                                  pygame.mixer.Sound.play(footstep)
                                   if Directions[Direction]=="North":
                                        if YCO!=0:
                                             UpRow=list(level[(YCO-1)])
                                             if str(UpRow[XCO])!="X":
                                                  YCO=YCO-1
                                                  pygame.mixer.Sound.play(footstep)
                                   if Directions[Direction]=="East":
                                        if XCO!=(len(Row)-1):
                                             if str(Row[(XCO+1)])!="X":
                                                  XCO=XCO+1
                                                  pygame.mixer.Sound.play(footstep)
                                   if Directions[Direction]=="South":     
                                        if YCO!=(len(level)-1):
                                             DownRow=list(level[(YCO+1)])
                                             if str(DownRow[XCO])!="X":
                                                  YCO=YCO+1
                                                  pygame.mixer.Sound.play(footstep)
                                   Spawn=random.randint(0,8)
                                   Wait=30
                                   if Spawn==0:
                                        BeforeEXP=EXP
                                        BeforeCoins=Coins
                                        Currhealth, EXP, Coins, Inventory=Combat(Strength, Defense, Health, Speed, Currhealth, LMIN, LMAX, EXP, Coins,Inventory)
                                        Battleover=1
                                        EXPchange=EXP-BeforeEXP
                                        Coinschange=Coins-BeforeCoins
                                        if Currhealth==0:
                                             Running=False
                            
                         if event.key == pygame.K_a:
                              if Direction==0:
                                   Direction=3
                              else:
                                   Direction=Direction-1  
                              Wait=30
                            
                         if event.key == pygame.K_d:
                              if Direction==3:
                                   Direction=0
                              else:
                                   Direction=Direction+1
                              Wait=30

                         if event.key == pygame.K_p:
                              Paused=1
                              Wait=30
                              
                         if event.key == pygame.K_z:
                              Inventory=Viewinventory(Inventory)
                        
          Wait=Wait-1
          
          while Battleover==1:
               EXPtoLVL=(50+100*LVL+1.2**LVL)-((50+100*LVL+1.2**LVL)%1)
               if EXP>=EXPtoLVL:
                    LVL=LVL+1
                    Points=Points+3
                    EXP=EXP-EXPtoLVL
                    LVLed=1
               EXPimg=pygame.image.load('Pause.png')
               Cancel=pygame.image.load('cancelbutton.png')
               EXPmenu=Button(75,25,0,0)
               cancelbutt=Button(350,50,30,30)
               screen.blit(EXPimg,EXPmenu.rect)
               screen.blit(Cancel,cancelbutt.rect)
               for event in pygame.event.get():
                    if event.type==pygame.MOUSEBUTTONDOWN:
                         mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
               if cancelbutt.rect.colliderect(mouse.rect):
                    Battleover=0
                    LVLed=0
                    mouse.rect.x,mouse.rect.y=0,0
               if LVLed==1:
                    if Points>0:
                         plusbutt=pygame.image.load('plusbutton.png')
                         plus1=Button(345,265,40,40)
                         plus2=Button(345,315,40,40)
                         plus3=Button(345,365,40,40)
                         plus4=Button(345,415,40,40)
                         if plus1.rect.colliderect(mouse.rect):
                              Points=Points-1
                              Strength=Strength+1
                         if plus2.rect.colliderect(mouse.rect):
                              Points=Points-1
                              Defense=Defense+1
                         if plus3.rect.colliderect(mouse.rect):
                              Points=Points-1
                              Health=Health+1
                              Currhealth=Currhealth+1
                         if plus4.rect.colliderect(mouse.rect):
                              Points=Points-1
                              Speed=Speed+1
                         mouse.rect.x,mouse.rect.y=0,0
                         screen.blit(plusbutt,plus1.rect)
                         screen.blit(plusbutt,plus2.rect)
                         screen.blit(plusbutt,plus3.rect)
                         screen.blit(plusbutt,plus4.rect)
                    LVLtext = Centertext("LEVEL UP", (250,50))
                    LVLtext.draw(screen)
                    data=Button(0,0,0,0)
                    output="Strength: " + str(Strength)
                    screen.blit(data.font.render((output),True,(0,0,0)),(100,275))
                    output="Defense: " + str(Defense)
                    screen.blit(data.font.render((output),True,(0,0,0)),(100,325))
                    output="Health: " + str(Health)
                    screen.blit(data.font.render((output),True,(0,0,0)),(100,375))
                    output="Speed: " + str(Speed)
                    screen.blit(data.font.render((output),True,(0,0,0)),(100,425))
                    EXPTOLVL=(50+100*LVL+1.2**LVL)-((50+100*LVL+1.2**LVL)%1)
                    output="Experience: " + str(EXP)+"/"+str(EXPTOLVL)
                    screen.blit(data.font.render((output),True,(0,0,0)),(100,175))
                    output="Stat Points: " + str(Points)
                    screen.blit(data.font.render((output),True,(0,0,0)),(100,225))
               EXPtext = Centertext("You have gained "+str(EXPchange)+" EXP", (250,110))
               EXPtext.draw(screen)
               Coinstext = Centertext("You have gained "+str(Coinschange)+" coins", (250,140))
               Coinstext.draw(screen)
               pygame.display.flip()
               
          if Shape=="A":
               pic=ADEC[Direction]
          if Shape=="B":
               pic=BDEC[Direction]
          if Shape=="C":
               pic=CDEC[Direction]
          if Shape=="D":
               pic=DDEC[Direction]
          if Shape=="E":
               pic=EDEC[Direction]
          if Shape=="F":
               pic=FDEC[Direction]
          if Shape=="G":
               pic=GDEC[Direction]
          if Shape=="H":
               pic=HDEC[Direction]
          if Shape=="I":
               pic=IDEC[Direction]
          if Shape=="J":
               pic=JDEC[Direction]
          if Shape=="K":
               pic=KDEC[Direction]
          if Shape=="L":
               pic=LDEC[Direction]
          if Shape=="M":
               pic=MDEC[Direction]
          if Shape=="N":
               pic=NDEC[Direction]
          if Shape=="O":
               pic=ODEC[Direction]
              
          if pic==I1:
               Walk=True
          else: 
               if pic==I4:
                    Walk=True
               else:     
                    if pic==I6:
                         Walk=True
                    else: 
                         if pic==I8:
                              Walk=True
                         else:
                              Walk=False

          screen.fill((0,0,0))
          screen.blit(pic,back.rect)
          if ((XCO==XEnd) and (YCO==YEnd)):
               mouse.rect.x,mouse.rect.y=0,0
               for event in pygame.event.get():
                    if event.type==pygame.MOUSEBUTTONDOWN:
                         mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
               ladder=pygame.image.load('ladderpng.png')
               ladderob=Button(0,0,0,0)
               screen.blit(ladder,ladderob.rect)
               escape=Button(125,355,250,30)
               escapetext = Centertext("Escape Dungeon", (250,375))
               pygame.draw.rect(screen,(150,150,150),escape.rect)
               escapetext.draw(screen)
               if escape.rect.colliderect(mouse.rect):
                    Running=False
          screen.blit(point.font.render((str(Directions[Direction])),True,(255,0,0)),(400,100))
          while Paused==1:
               mouse.rect.x,mouse.rect.y=0,0
               for event in pygame.event.get():
                    if event.type==pygame.MOUSEBUTTONDOWN:
                         mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
               resume=Button(150,85,200,30)
               resumetext = Centertext("Resume Game", (250,105))
               if resume.rect.colliderect(mouse.rect):
                    Paused=0
               leave=Button(150,385,200,30)
               leavetext = Centertext("Leave Dungeon", (250,405))
               if leave.rect.colliderect(mouse.rect):
                    Paused=0
                    Running=False
               mouse.rect.x,mouse.rect.y=0,0
               pausing=Button(75,25,0,0)
               pausemenu=pygame.image.load('Pause.png')
               screen.blit(pausemenu,pausing.rect)
               pygame.draw.rect(screen,(150,150,150),resume.rect)
               pygame.draw.rect(screen,(150,150,150),leave.rect)
               resumetext.draw(screen)
               leavetext.draw(screen)
               pygame.display.flip()
          pygame.display.flip()
     return LVL,Strength,Defense,Health,Speed,EXP,Points,Coins

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################

def screeninput(Desire):
     class Key(object):
          def __init__(self,x,y):
               self.rect=pygame.Rect(x,y,30,30)
     class Textbox(object):
          def __init__(self,x,y,a,b):
               self.rect=pygame.Rect(x,y,a,b)
               self.font=pygame.font.SysFont('Showcard Gothic',20)
     Board = pygame.image.load('Keyboard2.png')
     textbox=Textbox(150,200,200,30)
     enter=Textbox(200,275,100,30)
     abutt=Key(35,360)
     bbutt=Key(85,360)
     cbutt=Key(135,360)
     dbutt=Key(185,360)
     ebutt=Key(235,360)
     fbutt=Key(285,360)
     gbutt=Key(335,360)
     hbutt=Key(385,360)
     ibutt=Key(435,360)
     jbutt=Key(35,410)
     kbutt=Key(85,410)
     lbutt=Key(135,410)
     mbutt=Key(185,410)
     nbutt=Key(235,410)
     obutt=Key(285,410)
     pbutt=Key(335,410)
     qbutt=Key(385,410)
     rbutt=Key(435,410)
     sbutt=Key(35,460)
     tbutt=Key(85,460)
     ubutt=Key(135,460)
     vbutt=Key(185,460)
     wbutt=Key(235,460)
     xbutt=Key(285,460)
     ybutt=Key(335,460)
     zbutt=Key(385,460)
     undo=Key(435,460)
     Text=""
     mouse.rect.x,mouse.rect.y=0,0
     Typing=True
     while Typing==True:
          for event in pygame.event.get():
               if event.type==pygame.MOUSEBUTTONDOWN:
                    mouse.rect.x,mouse.rect.y=pygame.mouse.get_pos()
               if len(Text)<9:
                    if event.type == pygame.KEYDOWN:
                         if event.key == pygame.K_a:
                              Text=Text+"a"
                         if event.key == pygame.K_b:
                              Text=Text+"b"
                         if event.key == pygame.K_c:
                              Text=Text+"c"
                         if event.key == pygame.K_d:
                              Text=Text+"d"
                         if event.key == pygame.K_e:
                              Text=Text+"e"
                         if event.key == pygame.K_f:
                              Text=Text+"f"
                         if event.key == pygame.K_g:
                              Text=Text+"g"
                         if event.key == pygame.K_h:
                              Text=Text+"h"
                         if event.key == pygame.K_i:
                              Text=Text+"i"
                         if event.key == pygame.K_j:
                              Text=Text+"j"
                         if event.key == pygame.K_k:
                              Text=Text+"k"
                         if event.key == pygame.K_l:
                              Text=Text+"l"
                         if event.key == pygame.K_m:
                              Text=Text+"m"
                         if event.key == pygame.K_n:
                              Text=Text+"n"
                         if event.key == pygame.K_o:
                              Text=Text+"o"
                         if event.key == pygame.K_p:
                              Text=Text+"p"
                         if event.key == pygame.K_q:
                              Text=Text+"q"
                         if event.key == pygame.K_r:
                              Text=Text+"r"
                         if event.key == pygame.K_s:
                              Text=Text+"s"
                         if event.key == pygame.K_t:
                              Text=Text+"t"
                         if event.key == pygame.K_u:
                              Text=Text+"u"
                         if event.key == pygame.K_v:
                              Text=Text+"v"
                         if event.key == pygame.K_w:
                              Text=Text+"w"
                         if event.key == pygame.K_x:
                              Text=Text+"x"
                         if event.key == pygame.K_y:
                              Text=Text+"y"
                         if event.key == pygame.K_z:
                              Text=Text+"z"                              
                    if abutt.rect.colliderect(mouse.rect):
                         Text=Text+"a"
                    if bbutt.rect.colliderect(mouse.rect):
                         Text=Text+"b"
                    if cbutt.rect.colliderect(mouse.rect):
                         Text=Text+"c"
                    if dbutt.rect.colliderect(mouse.rect):
                         Text=Text+"d"
                    if ebutt.rect.colliderect(mouse.rect):
                         Text=Text+"e"
                    if fbutt.rect.colliderect(mouse.rect):
                         Text=Text+"f"
                    if gbutt.rect.colliderect(mouse.rect):
                         Text=Text+"g"
                    if hbutt.rect.colliderect(mouse.rect):
                         Text=Text+"h"
                    if ibutt.rect.colliderect(mouse.rect):
                         Text=Text+"i"
                    if jbutt.rect.colliderect(mouse.rect):
                         Text=Text+"j"
                    if kbutt.rect.colliderect(mouse.rect):
                         Text=Text+"k"
                    if lbutt.rect.colliderect(mouse.rect):
                         Text=Text+"l"
                    if mbutt.rect.colliderect(mouse.rect):
                         Text=Text+"m"
                    if nbutt.rect.colliderect(mouse.rect):
                         Text=Text+"n"
                    if obutt.rect.colliderect(mouse.rect):
                         Text=Text+"o"
                    if pbutt.rect.colliderect(mouse.rect):
                         Text=Text+"p"
                    if qbutt.rect.colliderect(mouse.rect):
                         Text=Text+"q"
                    if rbutt.rect.colliderect(mouse.rect):
                         Text=Text+"r"
                    if sbutt.rect.colliderect(mouse.rect):
                         Text=Text+"s"
                    if tbutt.rect.colliderect(mouse.rect):
                         Text=Text+"t"
                    if ubutt.rect.colliderect(mouse.rect):
                         Text=Text+"u"  
                    if vbutt.rect.colliderect(mouse.rect):
                         Text=Text+"v"
                    if wbutt.rect.colliderect(mouse.rect):
                         Text=Text+"w"
                    if xbutt.rect.colliderect(mouse.rect):
                         Text=Text+"x"
                    if ybutt.rect.colliderect(mouse.rect):
                         Text=Text+"y"
                    if zbutt.rect.colliderect(mouse.rect):
                         Text=Text+"z"
               if event.type == pygame.KEYDOWN:
                         if event.key == pygame.K_BACKSPACE:
                              Carry=Text
                              Text=""
                              for i in range(len(Carry)-1):
                                   Text=Text+Carry[i]
               if undo.rect.colliderect(mouse.rect):
                    Carry=Text
                    Text=""
                    for i in range(len(Carry)-1):
                         Text=Text+Carry[i]
               if len(Text)>0:
                    if event.type == pygame.KEYDOWN:
                         if event.key == pygame.K_RETURN:
                              Typing=False
                    if enter.rect.colliderect(mouse.rect):
                              Typing=False
               mouse.rect.x,mouse.rect.y=0,0
               
          screen.fill((0,0,0))
          screen.blit(Board,back.rect)
          pygame.draw.rect(screen,(100,100,100),enter.rect)
          screen.blit(textbox.font.render(("ENTER"),True,(0,0,0)),(215,280))
          pygame.draw.rect(screen,(255,255,255),textbox.rect)
          if len(Text)==0:
               Box="Insert "+Desire
               screen.blit(textbox.font.render((Box),True,(200,100,100)),(150,205))
          else:
               screen.blit(textbox.font.render((Text),True,(255,0,0)),(150,205))
          pygame.display.flip()
     return Text

#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
#######################################################################################################################################################################
          
while Running:
     clock.tick(60)      
     for event in pygame.event.get():
          if event.type == pygame.QUIT:
               running = False 
     mouse=Mouse()
     mainmenu()
