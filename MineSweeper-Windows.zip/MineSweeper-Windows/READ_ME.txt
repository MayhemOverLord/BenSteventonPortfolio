The minesweeper project was a game I made during the summer holidays prior to my final year at the University of Sussex.

This game follows the standard rules and mechanics of the minesweeper game:
You must uncover as many tiles as possible without disturbing the mines
If a tile has a number on it, it corresponds to how many mines are within one tile of it (diagonally inclusive)
The player can switch back and forth between digging and flagging by pressing the button
Flagging allows the player to place a flag on a suspected mine tile, preventing you from accidentally digging while flagged.
Digging on a mine tile will result in the player losing.

The software is currently only setup to work on android and windows devices. The android version can be run by installing the apk on an android device. The windows version needs to be downloaded, unzipped and then the user may run the MineSweeper.exe file to play the game.